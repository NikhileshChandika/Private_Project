## Overview

This repository contains resources for advanced data analytics project, mainly utilized by Informatica which is building on top of them. The stack is deployed by the parent pipeline automatically on commits.
More detailed documentation can be found here: https://minterellison.atlassian.net/browse/DAP-88
The pipeline stacks are located here: https://github.com/minterellison/aws_analytics_data_pipelines

## Services

The stack is using the following AWS services:

- apigateway
- athena
- dynamodb
- glue
- ec2
- iam
- kms
- lambda
- logs
- redshift
- s3
