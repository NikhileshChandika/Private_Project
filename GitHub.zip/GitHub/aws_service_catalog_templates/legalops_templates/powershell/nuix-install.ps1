

#-------------------------------------------------------
# Log all input/output
#-------------------------------------------------------
start-transcript -IncludeInvocationHeader -Path "C:\temp\logs\nuixinstall-$(get-date -f yyyy-MM-dd-HH-mm-ss).log"
 
Write-Host
Write-Host "-------------------------------------------------------------------------------"
Write-Host "$(Get-Date -format g): Executing Nuix Installation."
Write-Host "-------------------------------------------------------------------------------"
 
 
#-------------------------------------------------------
# Stop script on any errors
#-------------------------------------------------------
$ErrorActionPreference = "Stop"
 
 
#-------------------------------------------------------
# Check to see if PowerShell is running in elevated mode
#-------------------------------------------------------
Function CheckElevated() {
    $wid=[System.Security.Principal.WindowsIdentity]::GetCurrent()
    $prp=new-object System.Security.Principal.WindowsPrincipal($wid)
    $adm=[System.Security.Principal.WindowsBuiltInRole]::Administrator
    $IsAdmin=$prp.IsInRole($adm)
     if ($IsAdmin) {
                write-host "PowerShell is elevated, script will run"
                #pause
    } Else {
                write-host "PowerShell is not elevated, please run this script in elevated mode"
                pause
                exit(1)
    }
}

Function Create-BrokerFolder() {
    $logpath = 'D:\logs\broker'
    if (-not(Test-Path -Path $logpath -PathType Container)) {
         try {
             $null = New-Item -ItemType directory -Path $logpath -Force -ErrorAction Stop
             Write-Host "The Folder [$logpath] has been created."
         }
         catch {
             throw $_.Exception.Message
         }
     }
     else {
         Write-Host "Cannot create [$logpath] because a folder with that name already exists."
      }
    }

Function Create-WorkerFolder() {
$workerpath = 'D:\temp\worker'
if (-not(Test-Path -Path $workerpath -PathType Container)) {
     try {
         $null = New-Item -ItemType directory -Path $workerpath -Force -ErrorAction Stop
         Write-Host "The Folder [$workerpath] has been created."
     }
     catch {
         throw $_.Exception.Message
     }
 }
 else {
     Write-Host "Cannot create [$workerpath] because a folder with that name already exists."
   }
 }

 Function Create-JavaIOFolder() {
    $javaiopath = 'D:\temp\javaio'
    if (-not(Test-Path -Path $javaiopath -PathType Container)) {
         try {
             $null = New-Item -ItemType directory -Path $javaiopath -Force -ErrorAction Stop
             Write-Host "The Folder [$javaiopath] has been created."
         }
         catch {
             throw $_.Exception.Message
         }
     }
     else {
         Write-Host "Cannot create [$javaiopath] because a folder with that name already exists."
      }
    }

Function Disable-ieESC() {
    Try {
        $AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
        $UserKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
        Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0 -ErrorAction:Stop -ErrorVariable ErrVar  | Out-Null 
        Set-ItemProperty -Path $UserKey -Name "IsInstalled" -Value 0 -ErrorAction:Stop -ErrorVariable ErrVar  | Out-Null
        write-host "Sucessfully Disabled ieESC" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Function Install-Chrome() {
    $chromeInstalled = "C:\Program Files\Google\Chrome\Application\chrome.exe"
    if (-Not (Test-Path -Path $chromeInstalled)) {
    Try {
        $chromeInstallPath="C:\temp\Media\Base\Chrome.exe"
        $chromeInstallarguments = "/silent /install"
        Start-Process -FilePath $chromeInstallPath -Args $chromeInstallarguments -Verb RunAs -Wait
        write-host "Sucessfully Installed Chrome" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
  }
else {
    Write-Host "Google Chrome already exists."
  }
}

Function Install-NotepadPlusPlus() {
    $notepadplusplusInstalled = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where { $_.DisplayName -eq "Notepad++ (64-bit x64)" }) -ne $null
    if (-Not $notepadplusplusInstalled) {
    Try {
        $notepadplusplusInstallPath="C:\temp\Media\Base\Notepadplus.exe"
        $notepadplusplusInstallarguments = "/S"
        Start-Process -FilePath $notepadplusplusInstallPath -Args $notepadplusplusInstallarguments -Verb RunAs -Wait
        write-host "Sucessfully Installed Notepad++" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Notepad++ already exists."
  }
}

Function Install-7Zip() {
    $7ZipInstalled = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where { $_.DisplayName -eq "7-Zip 19.00 (x64 edition)" }) -ne $null
    if (-Not $7ZipInstalled) {
    Try {
        $7ZipInstallPath="C:\temp\Media\Base\7Zip.msi"
        $7ZipInstallarguments = "/i `"$7ZipInstallPath`" /quiet"
        Start-Process msiexec.exe -ArgumentList $7ZipInstallarguments -Wait
        write-host "Sucessfully Installed 7Zip"
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "7Zip already exists."
  }
}

Function Install-FileZilla() {
    $filezilla = "C:\Program Files (x86)\TechyGeeksHome.co.uk\FileZilla MSI Installer\filezilla.exe"
    if (-not(Test-Path -Path $filezilla)) {
    Try {
        $filezillaPath="C:\temp\Media\Base\FileZilla.msi"
        $filezillaarguments = "/i `"$filezillaPath`" /quiet"
        Start-Process msiexec.exe -ArgumentList $filezillaarguments -Wait
        write-host "Sucessfully Installed FileZilla" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "FileZilla already exists."
  }
}

Function Install-AdobeReader() {
    $adobeisthere = 'C:\Program Files (x86)\Adobe\Acrobat Reader DC\Reader\AcroRd32.exe'
    if (-not(Test-Path -Path $adobeisthere)) {
    Try {
        $AdobeInstallPath="C:\temp\Media\Base\AcroRd.exe"
        $AdobeInstallarguments = "/sAll /rs"
        Start-Process -FilePath $AdobeInstallPath -ArgumentList $AdobeInstallarguments -Wait
        write-host "Sucessfully Installed AdobeReader" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Adobe Reader already exists."
  }
}

Function Install-vcredist2010() {
    $vcredist2010Installed = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where { $_.DisplayName -eq "Microsoft Visual C++ 2010  x64 Redistributable - 10.0.40219" }) -ne $null
    if (-Not $vcredist2010Installed) {
    Try {
        C:\temp\Media\Base\vcredist_x64.exe /extract:c:\temp\Media\Base\vcredist_x64 /q
        Start-Sleep 5
        C:\temp\Media\Base\vcredist_x86.exe /extract:c:\temp\Media\Base\vcredist_x86 /q
        Start-Sleep 5
        $vcredistInstallarguments = "/q /norestart"
        Start-Process -FilePath c:\temp\Media\Base\vcredist_x64\Setup.exe -ArgumentList $vcredistInstallarguments -Wait -Passthru
        Start-Process -FilePath c:\temp\Media\Base\vcredist_x86\Setup.exe -ArgumentList $vcredistInstallarguments -Wait -Passthru
        write-host "Sucessfully Installed Microsoft Visual C++ 2010 Redistributable" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Microsoft Visual C++ 2010 Redistributable already exists."
  }
}

Function Install-orca() {
    $orcaisthere = 'C:\Program Files (x86)\Orca\Orca.exe'
    if (-not(Test-Path -Path $orcaisthere)) {
    Try {
        $OrcaInstallerFilePath="c:\temp\Media\Orca\Orca.msi"
        $Orcaarguments = "/i `"$OrcaInstallerFilePath`" /quiet"
        Start-Process msiexec.exe -ArgumentList $Orcaarguments -Wait
        write-host "Sucessfully Installed Orca" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Orca already exists."
  }
}

Function Install-nuixocr() {
    $nuixocrInstalled = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where { $_.DisplayName -eq "Nuix OCR Addon 12.4.7.239" }) -ne $null
    if (-Not $nuixocrInstalled) {
    Try {
        $nuixocrInstallerFilePath="C:\temp\Media\Nuix\Ocr\nuix-ocr-addon.msi"
        $nuixocrarguments = "/i `"$nuixocrInstallerFilePath`" /quiet"
        Start-Process msiexec.exe -ArgumentList $nuixocrarguments -Wait
        write-host "Sucessfully Installed Nuix OCR Addon 12.4.7.239" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Nuix OCR Addon 12.4.7.239 already exists."
  }
}

Function Install-nuix() {
    $nuixInstalled = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where { $_.DisplayName -eq "Nuix 9.0.3.416" }) -ne $null
    if (-Not $nuixInstalled) {
    Try {
        $nuixInstallerFilePath="C:\temp\Media\Nuix\Nuix\nuix.msi"
        $nuixarguments = "/i `"$nuixInstallerFilePath`" /quiet"
        Start-Process msiexec.exe -ArgumentList $nuixarguments -Wait
        write-host "Sucessfully Installed Nuix 9.0.3.416" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Nuix 9.0.3.416 already exists."
  }
}

Function Copy-nuixfiles() {
    $nuixfilesarethere = 'C:\Program Files\Nuix\Nuix 9.2\bin\ffmpeg.exe'
    if (-not(Test-Path -Path $nuixfilesarethere)) {
    Try {
        #Expand-Archive -LiteralPath C:\temp\ffmpeg-4.1.4-windows64-2019-08-12.zip -DestinationPath C:\temp -Force
        Copy-Item -Path "C:\temp\Media\Nuix\ffmpeg-4.1.4-win64-static\bin\*" -Destination "C:\Program Files\Nuix\Nuix 9.2\bin" -recurse -Force
        write-host "Sucessfully Nuix Files are been Copied" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Nuix Files already exists."
  }
}

Function Copy-startupfile() {
    $startupfilesarethere = 'C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\mapdrive.bat'
    if (-not(Test-Path -Path $startupfilesarethere)) {
    Try {
        Copy-Item -Path "C:\temp\scripts\mapdrive.bat" -Destination "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp" -recurse -Force
        write-host "Sucessfully Startup Script are been Copied" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Startup Script already exists."
  }
}

Function Install-LotusNotes() {
    $Notesisthere = 'C:\Program Files (x86)\IBM\Notes\nlnotes.exe'
    if (-not(Test-Path -Path $Notesisthere)) {
    Try {
        #Expand-Archive -LiteralPath C:\temp\Notes.zip -DestinationPath C:\temp -Force
        $NotesInstallerFilePath="C:\temp\Media\LotusNotes\IBM Notes 9.0.1 Social Edition.msi"
        $Notesarguments = "/i `"$NotesInstallerFilePath`" /quiet"
        Start-Process msiexec.exe -ArgumentList $Notesarguments -Wait
        write-host "Sucessfully Installed Lotus Notes" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Lotus Notes already exists."
  }
}

Function Install-VisioViewer() {
    $visioisthere = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where { $_.DisplayName -eq "Microsoft Visio Viewer 2016" }) -ne $null
    if (-Not $visioisthere) {
    Try {
        c:\temp\Media\Visio\VisioViewer.exe /quiet
        write-host "Sucessfully Installed Microsoft Visio Viewer 2016" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Microsoft Visio Viewer 2016 already exists."
  }
}

Function Copy-NuixEngineFolder() {
    $nuixenginefolder = 'C:\Program Files\Nuix\Nuix Engine'
    if (-not(Test-Path -Path $nuixenginefolder -PathType Container)) {
    Try {
        Expand-Archive -LiteralPath 'C:\temp\Media\Nuix\Nuix Engine.zip' -DestinationPath "C:\Program Files\Nuix\Nuix Engine" -Force
        write-host "Sucessfully Nuix Engine Folder has been Copied" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Nuix Engine Folder already exists."
  }
}

Function Install-Rampiva-Workflow() {
    $rampivaworkflow = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where { $_.DisplayName -eq "Rampiva Workflow for Nuix" }) -ne $null
    if (-Not $rampivaworkflow) {
    Try {
        #Expand-Archive -LiteralPath 'C:\temp\Rampiva files.zip' -DestinationPath "C:\temp\Rampiva files" -Force
        $RampivawfnInstallerFilePath="C:\temp\Media\Rampiva\rampiva-wfn.msi"
        $Rampivawfnarguments = "/i `"$RampivawfnInstallerFilePath`" /quiet"
        Start-Process msiexec.exe -ArgumentList $Rampivawfnarguments -Wait
        write-host "Sucessfully Installed Rampiva WorkFlow"
        $RampivasfnInstallerFilePath="C:\temp\Media\Rampiva\rampiva-sfn.msi"
        $Rampivasfnarguments = "/i `"$RampivasfnInstallerFilePath`" /quiet"
        Start-Process msiexec.exe -ArgumentList $Rampivasfnarguments -Wait
        write-host "Sucessfully Installed Rampiva Scheduler" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Rampiva Workflow for Nuix already Installed."
  }
}

Function Copy-RampivaConfigFile() {
    $rampivafile = 'C:\ProgramData\Rampiva\Scheduler for Nuix\Engine Server\config\config.yml'
    if (Test-Path -Path $rampivafile) {
    Try {
        Copy-Item -Path 'C:\temp\Media\Rampiva\config.yml' -Destination "C:\ProgramData\Rampiva\Scheduler for Nuix\Engine Server\config" -recurse -Force
        write-host "Sucessfully Rampiva Config File has been Copied" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Rampiva Config File Doesnot exists."
  }
}

Function Copy-JavaKeyStoreFile() {
    $JavaKeyStorefile = 'C:\ProgramData\Rampiva\Scheduler for Nuix\Engine Server\config\keystore.jks'
    if (Test-Path -Path $JavaKeyStorefile) {
    Try {
        Copy-Item -Path 'C:\temp\Media\KeyStore\keystore.jks' -Destination "C:\ProgramData\Rampiva\Scheduler for Nuix\Engine Server\config" -recurse -Force
        write-host "Sucessfully Java Key StoreFile has been Copied" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Java Key StoreFile Doesnot exists."
  }
}

Function Copy-RampivaServiceBatFile() {
    $RampivaServiceBatFile = 'C:\Program Files\Rampiva\Scheduler for Nuix\Engine Server\runService.bat'
    if (Test-Path -Path $RampivaServiceBatFile) {
    Try {
        Copy-Item -Path 'C:\temp\Media\Rampiva\runService.bat' -Destination "C:\Program Files\Rampiva\Scheduler for Nuix\Engine Server" -recurse -Force
        write-host "Sucessfully Rampiva ServiceBatFile has been Copied" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Rampiva ServiceBatFile Doesnot exists."
  }
}

Function Install-Openjdk() {
    $openjdkInstalled = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where { $_.DisplayName -eq "AdoptOpenJDK JDK with Hotspot 11.0.11+9 (x64)" }) -ne $null
    if (-Not $openjdkInstalled) {
    Try {
        $openjdkInstallerFilePath="C:\temp\Media\OpenJdk\OpenJDK.msi"
        $openjdkarguments = "/i `"$openjdkInstallerFilePath`" /quiet"
        Start-Process msiexec.exe -ArgumentList $openjdkarguments -Wait
        write-host "Sucessfully Installed OpenJdk" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "OpenJdk already exists."
  }
}

Function Copy-NuixProgramDataFolder() {
    $NuixProgramDataFolder = 'C:\temp\Media\Nuix\Programdata Nuix'
    if (Test-Path -Path $NuixProgramDataFolder) {
    Try {
        Copy-Item 'C:\temp\Media\Nuix\Programdata Nuix\*' -Destination "C:\ProgramData\Nuix" -Recurse -force
        write-host "Sucessfully Copied Files into ProgramData Nuix Folder" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "ProgramData Nuix Folder Doesnot exists."
  }
}

Function Disable-DirectoryCache() {
    Try {
        $DirectoryCacheLifetime = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters"
        Set-ItemProperty -Path $DirectoryCacheLifetime -Name "DirectoryCacheLlifetime" -Value 0 -ErrorAction:Stop -ErrorVariable ErrVar  | Out-Null 
        write-host "Sucessfully Disabled DirectoryCachelifeTime" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Install-Openjdk
Create-BrokerFolder
Create-WorkerFolder
Create-JavaIOFolder
Disable-ieESC
Install-Chrome
Install-NotepadPlusPlus
Install-7Zip
Install-vcredist2010
Install-AdobeReader
Install-VisioViewer
Install-FileZilla
Install-orca
Install-nuixocr
Install-nuix
Copy-nuixfiles
Copy-startupfile
Install-LotusNotes
Copy-NuixEngineFolder
Install-Rampiva-Workflow
Copy-RampivaConfigFile
Copy-JavaKeyStoreFile
Copy-RampivaServiceBatFile
Copy-NuixProgramDataFolder
Disable-DirectoryCache