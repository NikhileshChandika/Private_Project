#-------------------------------------------------------
# Log all input/output
#-------------------------------------------------------
start-transcript -IncludeInvocationHeader -Path "C:\temp\logs\officeinstall-$(get-date -f yyyy-MM-dd-HH-mm-ss).log"
 
Write-Host
Write-Host "-------------------------------------------------------------------------------"
Write-Host "$(Get-Date -format g): Executing Office & Access Installation."
Write-Host "-------------------------------------------------------------------------------"
 
 
#-------------------------------------------------------
# Stop script on any errors
#-------------------------------------------------------
$ErrorActionPreference = "Stop"
 
 
#-------------------------------------------------------
# Check to see if PowerShell is running in elevated mode
#-------------------------------------------------------
Function CheckElevated() {
    $wid=[System.Security.Principal.WindowsIdentity]::GetCurrent()
    $prp=new-object System.Security.Principal.WindowsPrincipal($wid)
    $adm=[System.Security.Principal.WindowsBuiltInRole]::Administrator
    $IsAdmin=$prp.IsInRole($adm)
     if ($IsAdmin) {
                write-host "PowerShell is elevated, script will run"
                #pause
    } Else {
                write-host "PowerShell is not elevated, please run this script in elevated mode"
                pause
                exit(1)
    }
}


Function Install-Access() {
    $accessisthere = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where { $_.DisplayName -eq "Microsoft Access 2016" }) -ne $null
    if (-Not $accessisthere) {
    Try {
        Expand-Archive -LiteralPath C:\temp\Media\Access\Access_2016_64.zip -DestinationPath C:\temp\Media\Access\ -Force
        C:\temp\Media\Access\Access_2016_64\setup.exe /adminfile C:\temp\Media\Access\Access_2016_64\access64.MSP
        write-host "Sucessfully Installed Microsoft Access 2016" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Microsoft Access 2016 already exists."
  }
}

Function Install-Office() {
    $officeisthere = (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Where { $_.DisplayName -eq "Microsoft Office Standard 2016" }) -ne $null
    if (-Not $officeisthere) {
    Try {
        Expand-Archive -LiteralPath C:\temp\Media\MSOffice\Office_2016_Std_x64.zip -DestinationPath C:\temp\Media\MSOffice -Force
        C:\temp\Media\MSOffice\Office_2016_Std_x64\setup.exe /adminfile C:\temp\Media\MSOffice\Office_2016_Std_x64\office64.MSP
        write-host "Sucessfully Installed Microsoft Office Standard 2016" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}
else {
  Write-Host "Microsoft Office Standard 2016 already exists."
  }
}

Install-Office
Start-Sleep -s 300
Install-Access