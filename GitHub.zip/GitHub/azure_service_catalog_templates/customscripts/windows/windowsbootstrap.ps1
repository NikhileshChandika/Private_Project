#-------------------------------------------------------
# Log all input/output
#-------------------------------------------------------

New-Item -Path "C:\temp" -Name "logs" -ItemType "directory"
Set-TimeZone "AUS Eastern Standard Time"

start-transcript -IncludeInvocationHeader -Path "C:\temp\logs\azurevm_boot-$(get-date -f yyyy-MM-dd-HH-mm-ss).log"
 
Write-Host
Write-Host "-------------------------------------------------------------------------------"
Write-Host "$(Get-Date -format g): Executing Windows BootStap Azure VM Installation."
Write-Host "-------------------------------------------------------------------------------"
 
 
#-------------------------------------------------------
# Stop script on any errors
#-------------------------------------------------------
$ErrorActionPreference = "Stop"


#-------------------------------------------------------
# Check to see if PowerShell is running in elevated mode
#-------------------------------------------------------
Function CheckElevatedPowershell() {
    $wid=[System.Security.Principal.WindowsIdentity]::GetCurrent()
    $prp=new-object System.Security.Principal.WindowsPrincipal($wid)
    $adm=[System.Security.Principal.WindowsBuiltInRole]::Administrator
    $IsAdmin=$prp.IsInRole($adm)
     if ($IsAdmin) {
                write-host "PowerShell is elevated, script will run"
                #pause
    } Else {
                write-host "PowerShell is not elevated, please run this script in elevated mode"
                pause
                exit(1)
    }
}

Function Disable-ieESC() {
    Try {
        $AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
        $UserKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
        Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0 -ErrorAction:Stop -ErrorVariable ErrVar  | Out-Null 
        Set-ItemProperty -Path $UserKey -Name "IsInstalled" -Value 0 -ErrorAction:Stop -ErrorVariable ErrVar  | Out-Null
        write-host "Sucessfully Disabled ieESC" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Function Disable-WindowsFirewall() {
    Try {
        Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False  | Out-Null
        write-host "Sucessfully Windows Firewall Disabled" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Function Update-LocalAdminPassword() {
    Try {
        Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
        Install-Module -Name Az.KeyVault -force
        Login-AzAccount -Identity -AccountId af050d57-a8c2-46de-8e42-b4fbcb9bd019
        $Password = Get-AzKeyVaultSecret -vaultName "meaz-prd-shd-inf-kv" -name "WindowsLocalAdminPassword"
        Set-LocalUser meadmin -Password $Password.SecretValue
        write-host "Sucessfully Updated Local Admin Password" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Function Initialize-Disk() {
    Try {
        $diskpartitionstyle = "raw"
        if(Get-Disk | Where partitionstyle -eq $diskpartitionstyle)
        {$disktype = "Yes"} else{$disktype = "No"}
        #Create Partitions
        Get-Disk | Where partitionstyle -eq 'raw' | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -DriveLetter F -UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel "Data" -Confirm:$false
        write-host "Sucessfully Initialized Disk and Created New Partition" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Function CreateDir() {
    Try {
        #Create Install Directories
        New-Item -Path "C:\" -Name "Install" -ItemType "directory"
        New-Item -Path "C:\Install" -Name "SCCM" -ItemType "directory"
        New-Item -Path "C:\Install" -Name "SCOM" -ItemType "directory"
        New-Item -Path "C:\Install" -Name "Scripts" -ItemType "directory"
        write-host "Sucessfully Created Install Directory" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Function SCCMCopy() {
    Try {
        Invoke-WebRequest -Uri https://meazprdshdinftemplatessa.blob.core.windows.net/meazprdshdinfmediacontainer/SCCM.zip -Outfile "C:\Install\SCCM\SCCM.ZIP"
        Expand-Archive -LiteralPath C:\Install\SCCM\SCCM.zip -DestinationPath C:\Install\SCCM -Force
        write-host "Sucessfully Copied SCCM Install Files" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Function SCOMCopy() {
    Try {
        Invoke-WebRequest -Uri https://meazprdshdinftemplatessa.blob.core.windows.net/meazprdshdinfmediacontainer/SCOM.zip -Outfile "C:\Install\SCOM\SCOM.ZIP"
        Expand-Archive -LiteralPath C:\Install\SCOM\SCOM.zip -DestinationPath C:\Install\SCOM -Force
        write-host "Sucessfully Copied SCOM Install Files" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Function RunonceScript() {
    Try {
        Invoke-WebRequest -Uri https://meazprdshdinftemplatessa.blob.core.windows.net/meazprdshdinfcustomscriptscontainer/agentsinstall.ps1 -Outfile "C:\Install\Scripts\agentsinstall.ps1"
        Invoke-WebRequest -Uri https://meazprdshdinftemplatessa.blob.core.windows.net/meazprdshdinfcustomscriptscontainer/agentsinstall.bat -Outfile "C:\Install\Scripts\agentsinstall.bat"
        Set-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce -Name InstallAgents -Value "C:\Install\Scripts\agentsinstall.bat" -Type String
        write-host "Sucessfully Copied Runonce Script" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Function RestartComputer() {
    Try {
        Restart-Computer -Force
        write-host "Sucessfully Restarted Computer" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Function DomainJoin() {
    Try {
        Login-AzAccount -Identity -AccountId af050d57-a8c2-46de-8e42-b4fbcb9bd019
        $DomainJoinUserName = Get-AzKeyVaultSecret -vaultName "meaz-prd-shd-inf-kv" -name "DomainJoinUserName" -AsPlainText 
        $DomainJoinPassword = Get-AzKeyVaultSecret -vaultName "meaz-prd-shd-inf-kv" -name "DomainJoinUserPassword"
        $DomainJoinOU = Get-AzKeyVaultSecret -vaultName "meaz-prd-shd-inf-kv" -name "DomainJoinOU" -AsPlainText
        $DomainName = Get-AzKeyVaultSecret -vaultName "meaz-prd-shd-inf-kv" -name "DomainName" -AsPlainText
        $cred = New-Object System.Management.Automation.PSCredential -ArgumentList $DomainJoinUserName, $DomainJoinPassword.SecretValue
        Add-Computer -DomainName $DomainName -Credential $cred -ou $DomainJoinOU
        write-host "Sucessfully Joined to Domain" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Function Uninstall-Defender() {
    Try {
        Uninstall-WindowsFeature -Name Windows-Defender
        write-host "Sucessfully Uninstalled Windows Defender" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}


CheckElevatedPowershell
Disable-ieESC
Disable-WindowsFirewall
Initialize-Disk
CreateDir
SCCMCopy
SCOMCopy
RunonceScript
Update-LocalAdminPassword
DomainJoin
Uninstall-Defender
RestartComputer
