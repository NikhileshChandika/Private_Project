#-------------------------------------------------------
# Log all input/output
#-------------------------------------------------------

start-transcript -IncludeInvocationHeader -Path "C:\temp\logs\app_install-$(get-date -f yyyy-MM-dd-HH-mm-ss).log"
 
Write-Host
Write-Host "-------------------------------------------------------------------------------"
Write-Host "$(Get-Date -format g): Executing Application_Installation On This VM."
Write-Host "-------------------------------------------------------------------------------"
 
 
#-------------------------------------------------------
# Stop script on any errors
#-------------------------------------------------------
$ErrorActionPreference = "Stop"


#-------------------------------------------------------
# Check to see if PowerShell is running in elevated mode
#-------------------------------------------------------
Function CheckElevatedPowershell() {
    $wid=[System.Security.Principal.WindowsIdentity]::GetCurrent()
    $prp=new-object System.Security.Principal.WindowsPrincipal($wid)
    $adm=[System.Security.Principal.WindowsBuiltInRole]::Administrator
    $IsAdmin=$prp.IsInRole($adm)
     if ($IsAdmin) {
                write-host "PowerShell is elevated, script will run"
                #pause
    } Else {
                write-host "PowerShell is not elevated, please run this script in elevated mode"
                pause
                exit(1)
    }
}

Function Install-SCOM() {
    Try {
        msiexec.exe /i C:\Install\SCOM\MOMAgent.msi /qn /l*v c:\temp\MOMAgentinstall.log USE_SETTINGS_FROM_AD=0 USE_MANUALLY_SPECIFIED_SETTINGS=1 MANAGEMENT_GROUP=MEOpsMgr MANAGEMENT_SERVER_DNS=DCUSVSCOM01.INT.MINTERELLISON.COM ACTIONS_USE_COMPUTER_ACCOUNT=1 AcceptEndUserLicenseAgreement=1
        write-host "Sucessfully Installed SCOM" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Function Install-SCCM() {
    Try {
        C:\Install\SCCM\ccmsetup.exe SMSSITECODE=MIN FSP=DCUSVSCCM01.int.minterellison.com
        write-host "Sucessfully Installed SCOM" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Function Activate-Windows() {
    Try {
        slmgr.vbs /ckms
        write-host "Cleared Azure KMS Entry"
        slmgr.vbs /skms-domain int.minterellison.com
        write-host "Set KMS Domain need to specify since server is not domain joined"
        slmgr.vbs /ato
        write-host "Windows Activated from ONprem KMS" 
    } catch {
        throw $_.Exception.Message
        exit(1)
    }
}

Activate-Windows
Install-SCOM
Install-SCCM
