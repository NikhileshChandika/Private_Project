######Keyvault Password############

from azure.keyvault.secrets import SecretClient
from azure.identity import ManagedIdentityCredential

keyVaultName = "meaz-prd-shd-inf-kv"
KVUri = f"https://{keyVaultName}.vault.azure.net"
secretName = "LinuxLocalAdminPassword"

credential = ManagedIdentityCredential()
client = SecretClient(vault_url=KVUri, credential=credential)
retrieved_secret = client.get_secret(secretName)

print(f"{retrieved_secret.value}")