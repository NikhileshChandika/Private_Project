echo BEGIN
date '+%Y-%m-%d %H:%M:%S'

#Hostname
#hostnamectl set-hostname czpi-antwp01

#Set instance time zone to Sydney time
timedatectl set-timezone Australia/Sydney

# Setup NTP
yum erase 'ntp*'
yum install chrony -y
sed -i '3 i\server 169.254.169.123 prefer iburst minpoll 4 maxpoll 4' /etc/chrony.conf
systemctl daemon-reload
systemctl restart chronyd.service
systemctl status chronyd.service
chkconfig chronyd on
chronyc sources -v
chronyc tracking

 # Install Certs
wget https://meaws-cfntemplates-bucket.s3-ap-southeast-2.amazonaws.com/certs/ROOTCA_B64.pem.cer -P /etc/pki/ca-trust/source/anchors/
wget https://meaws-cfntemplates-bucket.s3-ap-southeast-2.amazonaws.com/certs/SUBCA_B64.pem.cer -P /etc/pki/ca-trust/source/anchors/
update-ca-trust extract


 # Update Password
sudo pip3 install azure-keyvault-secrets
sudo pip3 install azure.identity
wget https://meazprdshdinftemplatessa.blob.core.windows.net/meazprdshdinfcustomscriptscontainer/keyvault.py -P /tmp/
cd /tmp
export password=$(python3 keyvault.py)
echo 'meadmin:'$password'' | sudo chpasswd

#Disk Partition
sudo parted /dev/sdc --script mklabel gpt mkpart xfspart xfs 0% 100%
sudo mkfs.xfs /dev/sdc1
sudo partprobe /dev/sdc1
sudo mkdir /datadir
sudo mount /dev/sdc1 /datadir
#sudo echo '/dev/sdc1 /datadir ext4 defaults,nofail 0 0' >> /etc/fstab