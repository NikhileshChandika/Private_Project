# azure_subscription_base
Azure Subscription Baselines (Landing Zone)
