﻿

# Ensures you do not inherit an AzContext in your runbook
Disable-AzContextAutosave -Scope Process

# Connect to Azure with user-assigned managed identity
Connect-AzAccount -Identity -AccountId 6fc31080-b351-4312-9028-1090e9b459f2

$allResources = @()

Write-Host "Selecting Subscriptions.."

$subscriptions=Get-AzSubscription | Where-Object -Property name -like meaz-*

Write-Host "Looping Through Subscriptions..."

ForEach ($vsub in $subscriptions){

Select-AzSubscription $vsub.SubscriptionID

Write-Host “Working on “ $vsub

#This is where you would set your custom Tags Keys and Values
$VMs = Get-AzVM  |  Where {$_.Tags.Keys -contains "OperationalPeriod" -and $_.Tags.Values -contains "D:8PM:6AM"} | Select Name, ResourceGroupName, Tags
ForEach ($VM in $VMs)
{
    $VMStatus2 = Get-AzVM -Name $VM.Name -ResourceGroupName $VM.ResourceGroupName -Status |
    Select Name, ResourceGroupName, DisplayStatus, Tags
    $VMN=$VM.Name
    $VMRG=$VM.ResourceGroupName
        If ($VMStatus = "VM deallocated")
            {
                Start-AzVM -Name $VMN -ResourceGroupName $VMRG
                "$VMN Started"
            }
                   
}

}



