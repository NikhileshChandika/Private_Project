## Overview

This repository contains automation pipelines divided in two groups - "core" (infrastructure), deploying AWS resources (e.g. S3 buckets, Redshift cluster, etc) and "data", facilitating Informatica config backup/restore.

## Assumptions

- The solution is designed for three AWS accounts structure: shared services (core and data pipelines), dev and prod (infrastructure stacks and auxilary IAM roles).

- The deploying user must have admin rights in all three accounts.

- The shared services account NAT Gateway public IP addresses must be added to Trusted IP Ranges in both dev and prod Informatica portals.

## Deployment

### Core stacks

1. In order to automatically provision stacks in dev and prod accounts the pipelines rely on a set of roles, specifically limited to their purpose. They must be provisioned in both dev and prod accounts from CFN template roles_pipelines.yml using AWS console, CLI or any orchestrating tool (e.g. ansible, terraform, etc).

2. Core stacks use Secrets Manager secrets for Redshift credentials - this has to be provisioned in both dev and prod accounts (named "Redshift" by default) with secret keys MasterUsername and MasterUserPassword.

3. Core pipelines notification webhook should be placed into secrets manager in shared services account (named "pipelines-teams-hook" by default). Once it's provisioned the ARN must be updated in core_pipelines.yml.

4. After that core pipeline must be provisioned the same way in the shared services account from core_pipelines.yml.

5. The central part of the core pipeline is the AWS CodeCommit repo (named "me-da-core" by default) with dev and prod environments served from the "dev" and "master" branches respectively. The newly created repo must be cloned to the DevOp machine, checked out to dev branch and synced from me-da-core directory in this repository. It contains two set of variables dev-config.json and prod-config.json, for dev and prod respectively that need to be reviewed and changed if required before the deployment.

6. Upon pushing the commit to dev branch the pipeline will deploy the core stack to dev account and send a notification to the configured webhook (e.g. Teams).

7. In order to provision infrastructure stack to prod account, the pull request needs to be raised, approved and merged into master branch. The prod pipeline will automatically provision the stack to prod account after pull request is merged.

### Data stacks

1. Data pipelines notification webhook should be placed into secrets manager in shared services account (named "pipelines-teams-hook" by default). Once it's provisioned the ARN must be updated in data_pipelines.yml.
Note: it could be the same or a different webhook as for core pipelines.

2. CodeBuild backup/restore projects need to be authenticated in GitHub. The username and the personal token should be placed into secrets manager in shared services account (named "pipelines-github-token" by default. Once it's provisioned the appropriate parameter in the stack should be updated (GitHubToken).

3. Data pipelines use Secrets Manager for Informatica credentials - this has to be provisioned in shared services account for both dev and prod environments:
- Secret: dev-informatica. Secret Keys: Username and Password.
- Secret: prod-informatica. Secret Keys: Username and Password.

4. After reviewing stack parameters and updating secret ARNs where required, data pipelines can be provision in shared services account from data_pipelines.yml.

## BAU operations

### Core

1. Commit change to the dev branch of core pipeline repo (named "me-da-core" by default).

2. When stack is deployed and tested raise a PR and merge it to the master branch - that will replicate the change to the prod stack.

Note: if deploying the updated stack requires extra permissions from auxilary IAM roles in the target account, those roles need to be updated and re-deployed first (as in roles_pipelines.yml), otherwise deployment will fail.

### Data

The core of the data pipelines is AWS CodeCommit repo (named "me-da-data" by default), used for storing Informatica config backups. The automation facilitates AWS CodeBuild and have three projects:

1. me-da-data-pipelines-backup-dev - copies dev Informatica config to dev branch.

2. me-da-data-pipelines-restore-dev - restores dev Informatica config from dev branch.

3. me-da-data-pipelines-restore-prod - restores prod Informatica config from prod branch.

In order to promote dev configuration to prod, the pull request needs to be raised, approved and merged to master branch, then project me-da-data-pipelines-restore-prod can be executed. It is assumed that no ad-hoc changes are made in prod so there is no need to back it up.

Note: Informatica won't backup connectors with credentials so if deleted they will have to be re-created manually.

## Services

The pipelines are using the following AWS services:

- codebuild
- codepipeline
- codestar-notifications
- ec2
- iam
- kms
- lambda
- logs
- s3
- sns
