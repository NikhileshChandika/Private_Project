# azure_firewall_rules
Terraform To Create Azure Firewall Rules
